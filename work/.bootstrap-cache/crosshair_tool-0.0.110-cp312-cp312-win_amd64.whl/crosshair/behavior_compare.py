"""
Capture and compare the *behavior* of a callable: run it (symbolically or
concretely), summarize the outcome (return value, exception type, in-place
mutation), and compare two runs with symbolic-friendly equality.

Used by CrossHair-on-CrossHair tests (``compare_results``/``compare_returns``),
the ``diffbehavior`` command (``flexible_equal``), and the single-operation
differential shared by ``fuzz_core_test`` and the support measurement
(``run_differential`` over a ``CallSpec``).

Nothing here reaches for ``crosshair.inputgen``, which needs hypothesis (a dev-only
extra): a caller builds the ``CallSpec`` and supplies its inputs.
"""

from collections.abc import Set as AbcSet
from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal
from time import process_time
from typing import (
    Any,
    Callable,
    Collection,
    Dict,
    FrozenSet,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
    cast,
)

from crosshair.core import (
    Patched,
    deep_realize,
    pin_to,
    proxy_for_type,
    suspected_proxy_intolerance_exception,
)
from crosshair.statespace import (
    CallAnalysis,
    IgnoreAttempt,
    RootNode,
    StateSpace,
    StateSpaceContext,
    context_statespace,
)
from crosshair.tracers import COMPOSITE_TRACER, NoTracing, ResumedTracing
from crosshair.util import (
    CrosshairUnsupported,
    assert_tracing,
    ch_stack,
    debug,
    in_debug,
    is_iterable,
    name_of_type,
)


class _Missing:
    pass


_MISSING = _Missing()


class _Unrealizable:
    """
    Sentinel type returned by `safe_deep_realize` when realization fails.

    Treated as equal to anything by `flexible_equal`, so unrealizable values
    do not poison comparisons (e.g. an arg that became a closed I/O stream).
    """

    def __repr__(self) -> str:
        return "<unrealizable>"


UNREALIZABLE = _Unrealizable()


def safe_deep_realize(
    value: object, label: str = "", memo: Optional[Dict] = None
) -> object:
    """
    Best-effort `deep_realize`.

    On any exception, debug-logs the failure and returns `UNREALIZABLE`,
    which `flexible_equal` treats as equal to anything. This is useful for
    diagnostic / comparison contexts (like post-state capture) where we
    don't want a non-realizable concrete object to mask the actual result.

    Pass a shared `memo` to preserve identity across multiple calls when
    realizing several values that may share substructure.
    """
    try:
        return deep_realize(value, memo)
    except Exception as exc:
        debug(
            "Could not realize",
            label or type(value).__name__,
            ":",
            type(exc).__name__,
            exc,
        )
        return UNREALIZABLE


def _is_nan(x: object) -> bool:
    if isinstance(x, float):
        return x != x
    if isinstance(x, Decimal):
        return x.is_nan()
    return False


def flexible_equal(a: object, b: object) -> bool:
    if a is b:
        return True
    if a is UNREALIZABLE or b is UNREALIZABLE:
        return True
    if type(a) is type(b) and type(a).__eq__ is object.__eq__:
        # If types match and it uses identity-equals, we can't do much. Assume equal.
        return True
    if _is_nan(a) and _is_nan(b):
        return True
    if (
        is_iterable(a)
        and not isinstance(a, Collection)
        and is_iterable(b)
        and not isinstance(b, Collection)
    ):  # unsized iterables compare by contents
        a, b = list(a), list(b)  # type: ignore
    if (
        type(a) == type(b)
        and isinstance(a, Collection)
        and not isinstance(a, (str, bytes, AbcSet))
    ):
        # Recursively apply flexible_equal for most containers:
        if len(a) != len(b):  # type: ignore
            return False
        if isinstance(a, Mapping):
            for k, v in a.items():
                if not flexible_equal(v, b.get(k, _MISSING)):  # type: ignore
                    return False
            return True
        else:
            return all(flexible_equal(ai, bi) for ai, bi in zip(a, b))  # type: ignore

    return a == b


@dataclass(eq=False)
class ExecutionResult:
    ret: object  # return value
    exc: Optional[BaseException]  # exception raised, if any
    tb: Optional[str]
    # args after the function terminates:
    post_args: Sequence
    post_kwargs: Mapping[str, object]

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ExecutionResult):
            return False
        return (
            flexible_equal(self.ret, other.ret)
            and type(self.exc) == type(other.exc)
            and flexible_equal(self.post_args, other.post_args)
            and flexible_equal(self.post_kwargs, other.post_kwargs)
        )

    def describe(self, include_postexec=False) -> str:
        ret = ""
        if self.exc:
            exc = self.exc
            exc_type = name_of_type(type(exc))
            tb = self.tb or "(missing traceback)"
            ret = f"exc={exc_type}: {str(exc)} {tb}"
        else:
            ret = f"ret={self.ret!r}"
        if include_postexec:
            a = [repr(a) for a in self.post_args]
            a += [f"{k}={v!r}" for k, v in self.post_kwargs.items()]
            ret += f'  post=({", ".join(a)})'
        return ret


@dataclass
class IterableResult:
    values: tuple
    typ: type


# The canonical builtin value types -- ``type(x) -> int`` is a stable, identity-eq
# inversion target, so these stay gradable.
_GRADABLE_CLASSES = frozenset(
    (int, float, bool, str, bytes, bytearray, list, tuple, dict, set, frozenset)
)


def _is_opaque(v: object, _depth: int = 0) -> bool:
    """True when value-comparing ``v`` (a result value) is meaningless: it is, or
    contains, an identity-eq object -- a callable, hash object, file handle, or an
    arbitrary class instance whose ``__eq__`` is ``object``'s.  ``run_differential``
    SKIPS such outputs (an honest "not checked") rather than reporting a spurious
    C-vs-Python-reimpl divergence, and the support map greys the same ops.

    Classes are split: a *canonical* builtin type (``type(x) -> int``) is a stable,
    identity-eq inversion target, so it stays gradable.  But an arbitrary class --
    e.g. the per-encoding StreamReader that ``codecs.getreader`` returns -- is no
    more checkable than a bare function, so it is opaque like any callable."""
    if v is None:
        return False
    if isinstance(v, type):
        return v not in _GRADABLE_CLASSES
    if callable(v):
        return True
    if isinstance(v, (str, bytes, bytearray, range)):
        return False
    if _depth < 3:
        if isinstance(v, Mapping):
            return any(_is_opaque(x, _depth + 1) for x in v.values())
        if isinstance(v, (list, tuple, set, frozenset)):
            return any(_is_opaque(x, _depth + 1) for x in v)
    return type(v).__eq__ is object.__eq__


def summarize_execution(
    fn: Callable,
    args: Sequence[object] = (),
    kwargs: Optional[Mapping[str, object]] = None,
    detach_path: bool = True,
) -> ExecutionResult:
    if not kwargs:
        kwargs = {}
    ret: object = None
    exc: Optional[Exception] = None
    tbstr: Optional[str] = None
    try:
        possibly_symbolic_ret = fn(*args, **kwargs)
        if detach_path:
            context_statespace().detach_path()
            detach_path = False
        ret_type = type(possibly_symbolic_ret)
        _ret = deep_realize(possibly_symbolic_ret)
        if hasattr(_ret, "__next__"):
            # Summarize any iterator as the values it produces, plus its type:
            ret = IterableResult(tuple(_ret), ret_type)  # type: ignore
        else:
            ret = _ret
    except Exception as e:
        exc = e
        if detach_path:
            context_statespace().detach_path(e)
        exc = deep_realize(exc)
        # NOTE: deep_realize somehow empties the __traceback__ member; re-assign it:
        exc.__traceback__ = e.__traceback__
        tbstr = ch_stack(currently_handling=exc)
        if in_debug():
            debug("hit exception:", type(exc), exc, tbstr)
    # Per-element best-effort realization: an unrealizable arg becomes
    # UNREALIZABLE (compares equal to anything in flexible_equal) without
    # poisoning sibling args. A shared memo preserves identity across
    # arguments that alias the same object.
    memo: Dict = {}
    args = tuple(
        safe_deep_realize(a, label=f"argument {idx + 1}", memo=memo)
        for idx, a in enumerate(args)
    )
    kwargs = {
        k: safe_deep_realize(v, label=f"keyword argument {k!r}", memo=memo)
        for k, v in kwargs.items()
    }
    return ExecutionResult(ret, exc, tbstr, args, kwargs)


@dataclass
class ResultComparison:
    left: ExecutionResult
    right: ExecutionResult

    def __bool__(self):
        return self.left == self.right and type(self.left) == type(self.right)

    def __repr__(self):
        left, right = self.left, self.right
        include_postexec = left.ret == right.ret and type(left.exc) == type(right.exc)
        return (
            left.describe(include_postexec)
            + "  <--symbolic-vs-concrete-->  "
            + right.describe(include_postexec)
        )


def compare_returns(fn: Callable, *a: object, **kw: object) -> ResultComparison:
    comparison = compare_results(fn, *a, **kw)
    comparison.left.post_args = ()
    comparison.left.post_kwargs = {}
    comparison.right.post_args = ()
    comparison.right.post_kwargs = {}
    return comparison


@assert_tracing(True)
def compare_results(fn: Callable, *a: object, **kw: object) -> ResultComparison:
    original_a = deepcopy(a)
    original_kw = deepcopy(kw)
    symbolic_result = summarize_execution(fn, a, kw)

    concrete_a = deep_realize(original_a)
    concrete_kw = deep_realize(original_kw)

    # Check that realization worked, too:
    with NoTracing():
        labels_and_args = [
            *(
                (f"Argument {idx + 1}", a[idx], arg)
                for idx, arg in enumerate(concrete_a)
            ),
            *((f"Keyword argument '{k}'", kw[k], v) for k, v in concrete_kw.items()),
        ]
        for label, symbolic_arg, concrete_arg in labels_and_args:
            with ResumedTracing():
                symbolic_type = type(symbolic_arg)
                concrete_type = type(concrete_arg)
            true_concrete_type = type(concrete_arg)
            assert (
                true_concrete_type == concrete_type
            ), f"{label} did not realize. It is {true_concrete_type} instead of {concrete_type}."
            assert (
                true_concrete_type == symbolic_type
            ), f"{label} should realize to {symbolic_type}; it is {true_concrete_type} instead."

    with NoTracing():
        concrete_result = summarize_execution(
            fn, concrete_a, concrete_kw, detach_path=False
        )
        debug("concrete_result:", concrete_result)

    ret = ResultComparison(symbolic_result, concrete_result)
    bool(ret)
    return ret


# ---------------------------------------------------------------------------
# single-operation differential: run an op with symbolic args pinned to chosen
# concrete values, then concretely, and compare.  A difference in return value,
# exception type, or in-place mutation is a soundness bug.  Shared by
# fuzz_core_test (assert no divergence) and the support measurement (color a cell
# black on any divergence).
# ---------------------------------------------------------------------------
_UNPINNED = object()  # could not pin a symbolic value to a given concrete input
_UNSUPPORTED = object()  # pinned fine, but the op rejected the symbolic proxy
# Thorough defaults (the support measurement's "leave no divergence unfound"
# budget).  A latency-sensitive caller (fuzz_core_test) passes a much smaller
# budget: nearly every input that pins at all does so on the first iteration in
# well under a second, so a large budget only slows the inputs that never pin.
_DIFF_MAX_PIN_ITERS = 80
_DIFF_PIN_TIMEOUT = 10.0


@dataclass(frozen=True)
class CallSpec:
    """How to call one operation.

    ``expr`` is eval-able source over ``arg_names`` (a method's receiver comes first
    and is named ``a``).  It is source rather than a callable because operators MUST
    be applied with operator syntax: ``list.__ge__(a, b)`` rejects a symbolic
    receiver, where ``a >= b`` does not.

    ``crosshair.inputgen.op_call``/``func_call`` build these, and
    ``crosshair.inputgen.inputs_for`` generates argument tuples for one.
    """

    fn: Any  # the underlying callable, for signature-based input generation
    expr: str
    arg_names: Tuple[str, ...]
    eval_globals: Mapping[str, Any]  # names ``expr`` needs beyond ``arg_names``
    # Index of the call shape this spec drives, into the op's ordered shape list
    # (``crosshair.inputgen.op_shapes``).  An op is driven once per shape: shapes
    # differ in which arguments they pass -- a different overload arity (pow's 2-
    # and 3-argument forms) or the optional/keyword-only tail filled in (subn's
    # ``count``).  ``inputs_for`` regenerates a shape's inputs from this index.
    shape: int

    def accepts(self, values: Sequence[Any]) -> bool:
        """Whether an argument tuple fits this expression."""
        return len(values) == len(self.arg_names)

    def invoke(self, values: Sequence[Any]) -> Any:
        """Evaluate the operation on one argument tuple."""
        return eval(
            self.expr, dict(self.eval_globals), dict(zip(self.arg_names, values))
        )


@dataclass
class Divergence:
    args: tuple  # the concrete inputs that diverged
    concrete: ExecutionResult
    symbolic: ExecutionResult

    def describe(self) -> str:
        return (
            f"on {self.args!r}:\n"
            f"  concrete: {self.concrete.describe(include_postexec=True)}\n"
            f"  symbolic: {self.symbolic.describe(include_postexec=True)}"
        )


@dataclass
class DiffResult:
    checked: int  # number of inputs actually driven (pinned + run) symbolically
    divergence: Optional[Divergence]  # first symbolic-vs-concrete mismatch, if any
    # inputs where CrossHair could pin the value but the op REJECTED the symbolic
    # proxy (proxy intolerance / CrosshairUnsupported) -- a modeling gap, NOT a
    # divergence.  When this is >0 and nothing diverged, the op is "unsupported".
    unsupported: int = 0


def _union_of(types: Iterable[object]) -> object:
    """Union of proxy types, order-preserved and de-duplicated."""
    uniq = tuple(dict.fromkeys(types))
    return uniq[0] if len(uniq) == 1 else Union[uniq]  # type: ignore


def _proxy_type(v: object) -> object:
    """A (possibly parameterized) type to build a symbolic stand-in for ``v``.

    A container's element type is a union over all of its elements."""
    t = type(v)
    if t is list:
        return List[_union_of(_proxy_type(x) for x in v)] if v else List[int]  # type: ignore
    if t is set:
        return Set[_union_of(_proxy_type(x) for x in v)] if v else Set[int]  # type: ignore
    if t is frozenset:
        return FrozenSet[_union_of(_proxy_type(x) for x in v)] if v else FrozenSet[int]  # type: ignore
    if t is tuple:
        return Tuple[tuple(_proxy_type(x) for x in v)] if v else Tuple[()]  # type: ignore
    if t is dict:
        if v:
            keys = _union_of(_proxy_type(k) for k in v)  # type: ignore
            vals = _union_of(_proxy_type(x) for x in v.values())  # type: ignore
            return Dict[keys, vals]  # type: ignore
        return Dict[int, int]
    return t


def run_symbolic_pinned(
    applier: Callable,
    arg_names: Sequence[str],
    concrete_vals: Sequence[object],
    max_pin_iters: int = _DIFF_MAX_PIN_ITERS,
    pin_timeout: float = _DIFF_PIN_TIMEOUT,
) -> object:
    """Run ``applier(*symbolic)`` with each symbolic arg pinned to its concrete
    value; return the ExecutionResult, or ``_UNPINNED`` if no path could be
    pinned within the budget.  ``pin_timeout`` caps each pin-and-run attempt (in
    process-time seconds)."""
    search_root = RootNode()
    with COMPOSITE_TRACER, NoTracing():
        for _itr in range(1, max_pin_iters + 1):
            space = StateSpace(
                process_time() + pin_timeout, 3.0, search_root=search_root
            )
            try:
                with Patched(), StateSpaceContext(space):
                    proxies = {
                        n: proxy_for_type(_proxy_type(v), n)
                        for n, v in zip(arg_names, concrete_vals)
                    }
                    with ResumedTracing():
                        # Pin each symbolic proxy to its concrete value, then run.
                        for name, value in zip(arg_names, concrete_vals):
                            pin_to(proxies[name], value)
                        res = summarize_execution(
                            applier, [proxies[n] for n in arg_names]
                        )
                # A proxy-intolerance TypeError (a C fn / coercion refusing the
                # symbolic value) is caught INSIDE summarize_execution and recorded
                # as res.exc.  The real analysis loop reclassifies it as
                # CrosshairUnsupported (see core.ExceptionFilter); do the same here
                # so it reads as "op unsupported", not "the op raised TypeError".
                if isinstance(
                    res.exc, Exception
                ) and suspected_proxy_intolerance_exception(res.exc):
                    return _UNSUPPORTED
                return res
            except IgnoreAttempt:
                pass  # this path didn't match the concrete value; try another
            except (KeyboardInterrupt, SystemExit):
                raise
            except CrosshairUnsupported:
                # The engine explicitly can't model this op here -- a coverage gap,
                # not a divergence.  (The op's OWN exceptions are Exception
                # subclasses, caught inside summarize_execution and compared.)
                return _UNSUPPORTED
            except BaseException:
                # UnknownSatisfiability / CrossHairInternal etc. -- "couldn't
                # check" (as opposed to "provably unsupported"); skip the input.
                return _UNPINNED
            _analysis, exhausted = space.bubble_status(CallAnalysis())
            if exhausted:
                return _UNPINNED
    return _UNPINNED


def run_differential(
    call: CallSpec,
    inputs: Sequence[Sequence[object]],
    max_pin_iters: int = _DIFF_MAX_PIN_ITERS,
    pin_timeout: float = _DIFF_PIN_TIMEOUT,
) -> DiffResult:
    """Drive one operation on each of ``inputs``, comparing a symbolic run (args
    pinned to the input) against a concrete run.  Returns a ``DiffResult`` with the
    count of inputs actually driven and the first ``Divergence`` (or None if all
    matched).  ``max_pin_iters`` and ``pin_timeout`` bound the per-input pin search;
    use small values when speed matters more than pinning every container shape (an
    input that can't pin in budget is simply skipped).

    Generate ``inputs`` with ``crosshair.inputgen.inputs_for(call)``, which fits
    them to ``call``'s overload shape."""
    arg_names = call.arg_names

    def applier(*vs):
        return call.invoke(vs)

    checked = 0
    unsupported = 0
    for vals in inputs:
        debug("differential:", call.expr, "with", vals)
        symbolic = run_symbolic_pinned(
            applier, arg_names, vals, max_pin_iters, pin_timeout
        )
        if symbolic is _UNPINNED:
            continue
        if symbolic is _UNSUPPORTED:
            # CrossHair couldn't MODEL the op on this input (the proxy was
            # rejected) -- incompleteness, not unsoundness.  Tally it separately so
            # callers can tell "unsupported" from "no divergence found".
            unsupported += 1
            continue
        concrete = summarize_execution(applier, deepcopy(list(vals)), detach_path=False)
        # Nondeterministic op?  If a second concrete run disagrees, the output
        # isn't a function of the inputs (RNG / time / id / set-ordering), so a
        # symbolic-vs-concrete mismatch here is meaningless -- skip the input.
        concrete2 = summarize_execution(
            applier, deepcopy(list(vals)), detach_path=False
        )
        if concrete != concrete2:
            continue
        if concrete.exc is None and _is_opaque(concrete.ret):
            # Output is (or contains) an identity-eq value -- not value-comparable,
            # so a symbolic-vs-concrete mismatch here is spurious (C vs Python
            # reimpl).  Don't count it; the support map greys these too.
            continue
        checked += 1
        if concrete != symbolic:
            return DiffResult(
                checked,
                Divergence(tuple(vals), concrete, cast(ExecutionResult, symbolic)),
                unsupported,
            )
    return DiffResult(checked, None, unsupported)
